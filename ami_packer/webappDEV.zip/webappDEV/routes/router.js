const router = require('express').Router();
const baseAuthentication = require('../util/auth.js');
const userController = require('../Controller/usersController.js');
const docController = require('../Controller/docController');
const multer = require('multer');

// GET Method

router.get("/healthz", (req, res) => {
    console.log("Api connected Successfully")
    res.sendStatus(200).json();
});

// POST Method

router.post("/v1/account", userController.createUser);

// GET Method (With Authentication)

router.get("/v1/account/:id", baseAuthentication() , userController.getUser);

// PUT Method

router.put("/v1/account/:id", baseAuthentication() , userController.updateUser);


const upload = multer({
    dest: 'uploads/'
})

router.post("/v1/documents", baseAuthentication(), upload.single('file'), docController.updateUserDoc);

// Get Picture

router.get("/v1/documents/:id", baseAuthentication(), docController.getUserDoc);

// Get All Picture

router.get("/v1/documents", baseAuthentication(), docController.getUserDocAll);

// Delete Picture

router.delete("/v1/documents/:id", baseAuthentication(), docController.deleteUserDoc);

module.exports = router;
